-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:8889
-- Généré le :  mer. 04 avr. 2018 à 13:06
-- Version du serveur :  5.6.38
-- Version de PHP :  7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `bdd_starchat`
--
CREATE DATABASE IF NOT EXISTS `bdd_starchat` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `bdd_starchat`;

-- --------------------------------------------------------

--
-- Structure de la table `historique_message`
--

CREATE TABLE `historique_message` (
  `heure` time NOT NULL,
  `id_message` int(11) NOT NULL,
  `text_message` text NOT NULL,
  `id_chat` int(11) NOT NULL,
  `id_utilisateur` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `historique_message`
--

INSERT INTO `historique_message` (`heure`, `id_message`, `text_message`, `id_chat`, `id_utilisateur`) VALUES
('14:53:35', 233, 'La force est puissante sur le chat ! ', 2, 1),
('15:04:15', 235, 'La peur je ressens en toi !', 1, 1),
('15:04:54', 236, 'J\'espère ne pas finir en morceaux !', 3, 1),
('15:15:50', 237, 'Tu veut une balle ?', 6, 1),
('15:16:28', 239, '(respiration forcer)', 5, 1),
('15:17:33', 240, 'Le Bien n\'est qu\'une question de point de vue.', 4, 1),
('16:40:27', 241, 'Hello world !', 4, 10),
('16:42:22', 242, 'Qu\'on m\'offre un ouvre-boîte ou je fais un malheur !', 3, 10),
('16:54:15', 243, 'Je te parle', 1, 1),
('11:03:32', 244, 'Nan pas trop.', 6, 14),
('18:02:41', 245, ';hhjvh,', 5, 15),
('23:06:03', 246, 'Je reparle pour voir si ça fonctionne.', 3, 15),
('10:51:22', 247, 'R2 ! Où es-tu mon vieux !', 3, 19),
('14:32:23', 248, 'Un trouble dans la force, je perçois', 1, 19),
('14:52:38', 249, 'Je sens le conflit en vous ! ', 2, 19),
('14:56:29', 250, 'Je sens le conflit en vous ! ', 2, 19);

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE `utilisateur` (
  `id_utilisateur` int(11) NOT NULL,
  `pseudo` varchar(255) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `motdepasse` text NOT NULL,
  `avatar` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`id_utilisateur`, `pseudo`, `mail`, `motdepasse`, `avatar`) VALUES
(19, '11', '1.1@1', '356a192b7913b04c54574d18c28d46e6395428ab', ''),
(20, 'test', 'test@test.test', 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3', '');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `historique_message`
--
ALTER TABLE `historique_message`
  ADD PRIMARY KEY (`id_message`);

--
-- Index pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD PRIMARY KEY (`id_utilisateur`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `historique_message`
--
ALTER TABLE `historique_message`
  MODIFY `id_message` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=251;

--
-- AUTO_INCREMENT pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  MODIFY `id_utilisateur` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
